<?php 
session_start();
include('admin/db_connect.php');
ob_start();
if(!isset($_SESSION['system'])){
	$system = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
	foreach($system as $k => $v){
		$_SESSION['system'][$k] = $v;
	}
}
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings</title>
    <meta content="" name="descriptison">
    <meta content="" name="keywords">



    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <link rel="stylesheet" href="admin/assets/font-awesome/css/all.min.css">


    <!-- Vendor CSS Files -->
    <link href="admin/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="admin/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="admin/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="admin/assets/vendor/venobox/venobox.css" rel="stylesheet">
    <link href="admin/assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="admin/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="admin/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="admin/assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <link href="admin/assets/DataTables/datatables.min.css" rel="stylesheet">
    <link href="admin/assets/css/jquery.datetimepicker.min.css" rel="stylesheet">
    <link href="admin/assets/css/select2.min.css" rel="stylesheet">


    <!-- Template Main CSS File -->
    <link href="admin/assets/css/style.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="admin/assets/css/jquery-te-1.4.0.css">

    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/DataTables/datatables.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/venobox/venobox.min.js"></script>
    <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counterup/counterup.min.js"></script>
    <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="assets/js/select2.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.datetimepicker.full.min.js"></script>
    <script type="text/javascript" src="assets/font-awesome/js/all.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery-te-1.4.0.min.js" charset="utf-8"></script>


    <style>
    button {
        border: none;
        background-color: black;
        color: white;
    }

    a {
        text-decoration: none;
        color: white;
    }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="./"><?php echo $_SESSION['system']['name'] ?></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto my-2 my-lg-0">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php?page=home">Home</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php?page=account">Account</a>
                    </li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php?page=about">About</a>
                    </li>



                </ul>
            </div>
        </div>
    </nav>
    <br>

    <div class="container-fluid">

        <div class="col-lg-12">
            <div class="row mb-4 mt-4">
                <div class="col-md-12">

                </div>
            </div>
            <div class="row">
                <!-- FORM Panel -->

                <!-- Table Panel -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <b>List of Books</b>
                        </div>
                        <div class="card-body">
                            <table class="table table-condensed table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th class="">Contact</th>
                                        <th class="">Date Pick-up</th>
                                        <th class="">Date Drop-off</th>
                                        <th class="">Car Info</th>
                                        <th class="">Status</th>
                                        <th class="">Payment Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
								$i = 1;
								$cat = array();
								$cat[] = '';
								$qry = $conn->query("SELECT * FROM categories ");
								while($row = $qry->fetch_assoc()){
									$cat[$row['id']] = $row['name'];
								}
								$tt = array();
								$tt[] = '';
								$qry = $conn->query("SELECT * FROM transmission_types ");
								while($row = $qry->fetch_assoc()){
									$tt[$row['id']] = $row['name'];
								}
								$et = array();
								$et[] = '';
								$qry = $conn->query("SELECT * FROM engine_types ");
								while($row = $qry->fetch_assoc()){
									$et[$row['id']] = $row['name'];
								}
                                 if (isset($_SESSION['username'])) : 
                                    $s_username = $_SESSION['username'];
                                    $type = array("","Admin","Staff","Alumnus/Alumna");
                                    $users = $conn->query("SELECT * FROM customers WHERE username = '$s_username'");
                                    $i = 1;
                                    while($row= $users->fetch_assoc()):
                                        $maile = $row["email"];
                                        $_SESSION['email'] = $maile;
                                        
                                    endwhile;
                                endif;
								$books = $conn->query("SELECT b.*,c.model,c.brand,c.transmission_id,c.engine_id FROM books b inner join cars c on c.id = b.car_id WHERE b.email='$maile'");
								while($row=$books->fetch_assoc()):
									
								?>
                                    <tr>
                                        <td class="text-center"><?php echo $i++ ?></td>
                                        <td class="">
                                            <p> <b><?php echo ucwords($row['contact']) ?></b></p>
                                        </td>
                                        <td class="">
                                            <p> <b><?php echo date("M d,Y h:i A",strtotime($row['pickup_datetime'])) ?></b>
                                            </p>
                                        </td>
                                        <td class="">
                                            <p> <b><?php echo date("M d,Y h:i A",strtotime($row['dropoff_datetime'])) ?></b>
                                            </p>
                                        </td>
                                        <td>
                                            <p>Brand: <b><?php echo ucwords($row['brand']) ?></b></p>
                                            <p>Model: <b><?php echo ucwords($row['model']) ?></b></p>
                                        </td>
                                        <td>
                                            <?php if($row['status'] == 1): ?>
                                            <span class="badge badge-secondary">Pending</span>
                                            <?php elseif($row['status'] == 2): ?>
                                            <span class="badge badge-primary">Confirmed</span>
                                            <?php else: ?>
                                            <span class="badge badge-danger">Canceled</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($row['pstatus'] == 2): ?>
                                            <h5>PAID</h5>
                                            <?php elseif($row['pstatus'] == 2 && $row['status'] == 2): ?>
                                            <h5>PAID</h5>
                                            <?php elseif($row['status'] == 2): ?>
                                            <button><a href="payment/index.php">Pay Now</a></button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Table Panel -->
            </div>
        </div>

    </div>
    <style>
    td {
        vertical-align: middle !important;
    }

    td p {
        margin: unset
    }

    img {
        max-width: 100px;
        max-height: :150px;
    }
    </style>
    <script>
    $(document).ready(function() {
        $('table').dataTable()
    })

    $('.view_book').click(function() {
        window.open("../index.php?page=view_book&id=" + $(this).attr('data-id'))

    })
    $('#new_book').click(function() {
        uni_modal("New Book", "manage_booking.php", "mid-large")

    })
    $('.edit_book').click(function() {
        uni_modal("Manage Book Details", "manage_booking.php?id=" + $(this).attr('data-id'), "mid-large")

    })
    $('.delete_book').click(function() {
        _conf("Are you sure to delete this book?", "delete_book", [$(this).attr('data-id')])
    })

    function delete_book($id) {
        start_load()
        $.ajax({
            url: 'ajax.php?action=delete_book',
            method: 'POST',
            data: {
                id: $id
            },
            success: function(resp) {
                if (resp == 1) {
                    alert_toast("Data successfully deleted", 'success')
                    setTimeout(function() {
                        location.reload()
                    }, 1500)

                }
            }
        })
    }
    </script>

</body>

</html>