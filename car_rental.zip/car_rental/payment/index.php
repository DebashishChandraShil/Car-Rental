<?php
session_start();
require('config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="../"><?php echo $_SESSION['system']['name'] ?></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto my-2 my-lg-0">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="../index.php?page=home">Home</a>
                    </li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger"
                            href="../index.php?page=account">Account</a>
                    </li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="../index.php?page=about">About</a>
                    </li>



                </ul>
            </div>
        </div>
    </nav>
    <div class="container text-center">
        <br><br><br><br>
        <img src="img/card.png" alt="" style="max-width:90%"><br><br>
        <div class="row">
            <div class="text-center">
                <form action="submit.php" method="post">
                    <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                        data-key="<?php echo $publishableKey?>" data-amount="100000" data-name="Maa Rent-a-Car"
                        data-description="A Complete Solution to Rent Service" data-image="img/cards.png"
                        data-currency="bdt" data-email="debashish69@gmail.com">
                    </script>

                </form>
            </div>
        </div>
    </div>
</body>

</html>