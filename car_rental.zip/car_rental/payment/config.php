<?php
require('stripe-php-master/init.php');

$publishableKey="pk_test_51MG8HDBbeSpjuQJL5Xd4cRNJe1rVFRhcxbW2s24LBaJcsMmvDRWAN7cbo1rSxo6I06ccZYc3UYLwbAXsVSYWRSlB00Uxn5nq8d";

$secretKey="sk_test_51MG8HDBbeSpjuQJLJoeEyjKgizwKSkOI1NWOQ4zfsDHTbWWMfFvmg2wBlkPGczercLhXp4ryxwK7ZXwGGRAP8S3e00YqrRTrHM";

\Stripe\Stripe::setApiKey($secretKey);
?>