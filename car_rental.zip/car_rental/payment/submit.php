<?php
require('config.php');
if(isset($_POST['stripeToken'])){
	\Stripe\Stripe::setVerifySslCerts(false);

	$token=$_POST['stripeToken'];

	$data=\Stripe\Charge::create(array(
		"amount"=>100000,
		"currency"=>"bdt",
		"description"=>"Maa Rent-a-Car",
		"source"=>$token,
	));
	?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Succesfull</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="container">
        <button style="border:none; background:black;"><a href="../index.php"
                style="text-decoration: none;color:white">Go to Home</a></button>
        <h1>Payment Successfull. Your Trx.ID is - <?php echo $data->balance_transaction; ?></h1>
        <div class="row text-center">
            <div class="col-md5">
                <table>
                    <tr>
                        <td>Email</td>
                        <td><?php echo $data->billing_details->name; ?></td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td>Gendaria , Dhaka</td>
                    </tr>
                    <tr>
                        <td>Amount</td>
                        <td><?php echo $data->amount; ?></td>
                    </tr>
                    <tr>
                        <td>Contact</td>
                        <td>01720 124547</td>
                    </tr>
                    <tr>
                        <td>trxID</td>
                        <td><?php echo $data->balance_transaction; ?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>successfull</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>

</html>





<?php
}
?>