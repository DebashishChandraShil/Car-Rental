<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include('admin/db_connect.php');
ob_start();
if(!isset($_SESSION['system'])){
	$system = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
	foreach($system as $k => $v){
		$_SESSION['system'][$k] = $v;
	}
}
ob_end_flush();
?>

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo $_SESSION['system']['name'] ?></title>


    <?php include('./header.php'); ?>
    <?php 
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

?>
    <style>
    body {
        font-family: Arial;
    }

    /* Style the tab */
    .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
        margin-top: 5em;
    }

    /* Style the buttons inside the tab */
    .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #ddd;
    }

    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #ccc;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
        background-color: white;
    }


    .profile {
        background-color: #fff;
    }

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 60%;
        margin-left: auto;
        margin-right: auto;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px 20px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }
    </style>
</head>

<body>
    <div class="tab">
        <button class="tablinks" onclick="openCity(event, 'London')" id="defaultOpen">Profile</button>
        <button class="tablinks" onclick="openCity(event, 'Paris')"><a
                href="registration/register.php">Registration</a></button>
        <button class="tablinks" onclick="openCity(event, 'Tokyo')"><a href="registration/login.php">Login</a></button>
        <button class="tablinks" onclick="openCity(event, 'Dhaka')"><a href="books.php">My Bookings</a></button>
        <button class="tablinks" onclick="openCity(event, 'Venice')"><a
                href="registration/logout.php">Logout</a></button>
    </div>

    <div id="London" class="tabcontent">
        <div class="profile">
            <?php  if (isset($_SESSION['username'])) : 
            $s_username = $_SESSION['username'];
            $type = array("","Admin","Staff","Alumnus/Alumna");
            $users = $conn->query("SELECT * FROM customers WHERE username = '$s_username'");
            $i = 1;
            while($row= $users->fetch_assoc()):    
                
            ?>
            <table>
                <tr>
                    <td>Name</td>
                    <td><?php echo $row['name']; ?></td>
                </tr>
                <tr>
                    <td>UserName</td>
                    <td><?php echo $row['username']; ?></td>
                </tr>
                <tr>
                    <td>E mail</td>
                    <td><?php echo $row['email']; ?></td>
                </tr>
                <tr>
                    <td>Contact No.</td>
                    <td><?php echo $row['contact']; ?></td>
                </tr>
            </table>
            <?php endwhile; ?>
            <?php endif ?>
        </div>
    </div>

    <div id="Paris" class="tabcontent">

    </div>

    <div id="Tokyo" class="tabcontent">
        <h3><a href="registration/login.php">Login</a></h3>
    </div>

    <div id="Dhaka" class="tabcontent">
        <h1><a href="books.php">Bookings</a></h1>
    </div>

    <script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
    </script>



    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
</body>
<script>
$('#login-form').submit(function(e) {
    e.preventDefault()
    $('#login-form button[type="button"]').attr('disabled', true).html('Logging in...');
    if ($(this).find('.alert-danger').length > 0)
        $(this).find('.alert-danger').remove();
    $.ajax({
        url: 'admin/ajax.php?action=login',
        method: 'POST',
        data: $(this).serialize(),
        error: err => {
            console.log(err)
            $('#login-form button[type="button"]').removeAttr('disabled').html('Login');

        },
        success: function(resp) {
            if (resp == 1) {
                location.href = 'index.php?page=home';
            } else {
                $('#login-form').prepend(
                    '<div class="alert alert-danger">Username or password is incorrect.</div>')
                $('#login-form button[type="button"]').removeAttr('disabled').html('Login');
            }
        }
    })
})
</script>

</html>